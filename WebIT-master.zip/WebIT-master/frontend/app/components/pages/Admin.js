import React from "react"
import ReactDOM from "react-dom"


class Admin extends React.Component {

  render() {
    return (
      <h1>Login to enter admin panel.</h1>
    );
  }

}

export default Admin;
