import React from "react"
import ReactDOM from "react-dom"
import {BrowserRouter, Switch, Route} from "react-router-dom"


class App extends React.Component {

  render() {
    return (
      <div>
        <h1>Welcome to WebIT</h1>
        <p>
          This is the built-in example project.
          To load an external project see the documentation.
        </p>
      </div>
    );
  }

}

export default App;
